import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';


//import { AboutusComponent } from './about_us/aboutus.component';
//import { CommonModule } from './common/common.module';
import { UserPreferenceComponent } from './user_preference/user_preference.component';

import { WorkforcePlanningComponent } from './workforce_planning/workforce_planning.component';

//import { IndustriesComponent } from './industries/industries.component';
//import { ProductsComponent } from './products/products.component';
//import { ContactusComponent } from './contact_us/contactus.component';


const appRoutes: Routes = [

  { path: '', redirectTo: '/user-preferences', pathMatch: 'full' },
  {
    path: 'workforce-planning',
    component: WorkforcePlanningComponent
  },
  {
    path: 'user-preferences',
    component: UserPreferenceComponent
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      appRoutes, { useHash: true })
  ],
  exports: [
    RouterModule
  ],
  providers: []
})
export class AppRoutingModule { }