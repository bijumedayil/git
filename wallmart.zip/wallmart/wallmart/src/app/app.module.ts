import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
//import { IndustriesModule } from './industries/industries.module';
//import { ProductsModule } from './products/products.module';
//import { ContactusModule } from './contact_us/contactus.module';


import {AppRoutingModule} from './app-routing.module';

import { AppComponent } from './app.component';
import { UserPreferenceModule } from './user_preference/user_preference.module';
import { WorkforcePlanningModule } from './workforce_planning/workforce_planning.module';
//import { AboutusModule } from './about_us/aboutus.module';
// import { CommonComponent } from './common.component';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    UserPreferenceModule,
    AppRoutingModule,
    WorkforcePlanningModule
    //IndustriesModule,
    //ProductsModule,
    //ContactusModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
