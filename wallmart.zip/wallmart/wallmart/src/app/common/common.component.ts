import { Component,ElementRef, AfterViewInit } from '@angular/core';


@Component({
  selector: 'main-component',
  templateUrl: './common.tpl.html'
})
export class CommonComponent implements AfterViewInit {
 	private industries:any[];
  	constructor(){
  		
  	}
  ngAfterViewInit() {
    
  }
}
