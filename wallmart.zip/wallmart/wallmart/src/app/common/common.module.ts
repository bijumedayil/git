import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { CommonComponent } from './common.component';

@NgModule({
  declarations: [
    CommonComponent
  ],
  imports:[BrowserModule],
  exports:[CommonComponent],
  providers: [],
})
export class CommonModule { }
