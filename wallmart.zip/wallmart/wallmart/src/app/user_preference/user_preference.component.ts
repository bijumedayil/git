import { Component } from '@angular/core';

@Component({
  selector: 'user-preference',
  templateUrl: 'user_preference.tpl.html'
})
export class UserPreferenceComponent {
  title = 'app';
}
