import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {UserPreferenceComponent} from './user_preference.component';


@NgModule({
  declarations: [
    UserPreferenceComponent
  ],
  imports: [
    BrowserModule
  ],
  exports:[UserPreferenceComponent],
  providers: []
})
export class UserPreferenceModule { }
