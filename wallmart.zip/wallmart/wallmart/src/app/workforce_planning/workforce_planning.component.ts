import { Component } from '@angular/core';

@Component({
  selector: 'workforce-planning',
  templateUrl: './workforce_planning.tpl.html'
})
export class WorkforcePlanningComponent {
  title = 'app works!';
}
