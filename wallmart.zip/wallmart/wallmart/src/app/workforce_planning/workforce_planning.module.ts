import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { WorkforcePlanningComponent } from './workforce_planning.component';

@NgModule({
  declarations: [
    WorkforcePlanningComponent
  ],
  exports:[WorkforcePlanningComponent],
  providers: [],
})
export class WorkforcePlanningModule { }
